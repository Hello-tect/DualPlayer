# Cloud build

Upload this project to GitHub. Then open **Actions**, select **Build Dual Player APK**, and choose **Run workflow**. When it finishes, download the **DualPlayer-debug-apk** artifact from the workflow run and install the APK on your tablet.
