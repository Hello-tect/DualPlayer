package com.example.dualplayer

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView
import kotlin.math.max
import kotlin.math.min

private val Bg = Color(0xFF090D10)
private val Panel = Color(0xFF151A1E)
private val Panel2 = Color(0xFF101519)
private val Accent = Color(0xFF38D38B)
private val Text = Color(0xFFE8ECEF)
private val Muted = Color(0xFF9AA4AA)

data class Slot(
    val uri: Uri? = null,
    val title: String = "No media selected",
    val aMs: Long? = null,
    val bMs: Long? = null
)

data class Page(val left: Slot = Slot(), val right: Slot = Slot())

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DualPlayerApp() }
    }
}

@Composable
fun DualPlayerApp() {
    var pages by remember { mutableStateOf(listOf(Page())) }
    var pageIndex by remember { mutableIntStateOf(0) }
    var selectingSlot by remember { mutableStateOf(-1) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null && selectingSlot >= 0) {
            val i = selectingSlot
            pages = pages.mapIndexed { pi, p ->
                if (pi != pageIndex) p
                else if (i == 0) p.copy(left = Slot(uri, "Media ${pi * 2 + 1}"))
                else p.copy(right = Slot(uri, "Media ${pi * 2 + 2}"))
            }
        }
        selectingSlot = -1
    }

    val page = pages[pageIndex]

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            TopBar(
                pageCount = pages.size,
                onAddPage = {
                    pages = pages + Page()
                    pageIndex = pages.lastIndex
                }
            )

            Row(
                Modifier.weight(1f).fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PlayerCard(
                    modifier = Modifier.weight(1f),
                    slot = page.left,
                    number = pageIndex * 2 + 1,
                    onOpen = { selectingSlot = 0; picker.launch(arrayOf("video/*", "audio/*")) },
                    onUpdate = { newSlot ->
                        pages = pages.mapIndexed { i, p ->
                            if (i == pageIndex) p.copy(left = newSlot) else p
                        }
                    }
                )
                PlayerCard(
                    modifier = Modifier.weight(1f),
                    slot = page.right,
                    number = pageIndex * 2 + 2,
                    onOpen = { selectingSlot = 1; picker.launch(arrayOf("video/*", "audio/*")) },
                    onUpdate = { newSlot ->
                        pages = pages.mapIndexed { i, p ->
                            if (i == pageIndex) p.copy(right = newSlot) else p
                        }
                    }
                )
            }

            BottomPager(
                index = pageIndex,
                count = pages.size,
                onPrev = { pageIndex = max(0, pageIndex - 1) },
                onNext = { pageIndex = min(pages.lastIndex, pageIndex + 1) }
            )
        }
    }
}

@Composable
fun TopBar(pageCount: Int, onAddPage: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(62.dp).background(Color(0xFF0C1115)).padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Dual Player", color = Text, fontSize = 21.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.weight(1f))
        Text("⊕  NEW PAGE", color = Text, fontSize = 15.sp,
            modifier = Modifier.clickable { onAddPage() }.padding(12.dp))
        Text("☷", color = Text, fontSize = 25.sp, modifier = Modifier.padding(12.dp))
        Text("⋮", color = Text, fontSize = 26.sp, modifier = Modifier.padding(6.dp))
    }
}

@Composable
fun PlayerCard(
    modifier: Modifier,
    slot: Slot,
    number: Int,
    onOpen: () -> Unit,
    onUpdate: (Slot) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var player by remember(slot.uri) { mutableStateOf<ExoPlayer?>(null) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var a by remember(slot.uri) { mutableStateOf(slot.aMs) }
    var b by remember(slot.uri) { mutableStateOf(slot.bMs) }
    var speed by remember { mutableFloatStateOf(1f) }
    var volume by remember { mutableFloatStateOf(1f) }
    var looping by remember { mutableStateOf(false) }

    DisposableEffect(slot.uri) {
        if (slot.uri != null) {
            val exo = ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(slot.uri))
                prepare()
                playWhenReady = false
            }
            player = exo
        }
        onDispose {
            player?.release()
            player = null
        }
    }

    LaunchedEffect(player) {
        while (true) {
            val p = player
            if (p != null) {
                position = p.currentPosition
                duration = max(0L, p.duration)
                val bb = b
                val aa = a
                if (bb != null && aa != null && position >= bb) {
                    p.seekTo(aa)
                }
            }
            kotlinx.coroutines.delay(250)
        }
    }

    Column(modifier.background(Panel, RoundedCornerShape(8.dp))) {
        Row(
            Modifier.height(52.dp).fillMaxWidth().background(Panel2).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("☷", color = Text, fontSize = 21.sp)
            Spacer(Modifier.width(12.dp))
            Text("Player $number", color = Text, fontSize = 17.sp)
            Spacer(Modifier.weight(1f))
            Text("CC", color = Text, fontWeight = FontWeight.Bold, modifier = Modifier.padding(8.dp))
            Text("♬", color = Text, fontSize = 21.sp, modifier = Modifier.padding(8.dp))
            Text("${speed}x", color = Text, modifier = Modifier.padding(8.dp))
            Text("↻", color = Text, fontSize = 22.sp, modifier = Modifier
                .clickable {
                    looping = !looping
                    player?.repeatMode = if (looping) ExoPlayer.REPEAT_MODE_ONE else ExoPlayer.REPEAT_MODE_OFF
                }.padding(8.dp))
            Text("⋮", color = Text, fontSize = 23.sp)
        }

        Box(
            Modifier.fillMaxWidth().weight(1f).background(Color.Black).clickable { if (slot.uri == null) onOpen() },
            contentAlignment = Alignment.Center
        ) {
            if (player != null) {
                AndroidView(
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            this.player = player
                            useController = false
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Text("+  ADD MEDIA", color = Accent, fontSize = 18.sp, modifier = Modifier.clickable { onOpen() })
            }
        }

        TimeBar(position, duration, player)

        // A-B strip — the main function requested.
        Row(
            Modifier.fillMaxWidth().height(68.dp).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("←", color = Text, fontSize = 22.sp)
            SmallButton("‹") {
                val p = player ?: return@SmallButton
                p.seekTo(max(0L, p.currentPosition - 1000))
            }
            ABButton("A", a) {
                a = player?.currentPosition
                onUpdate(slot.copy(aMs = a, bMs = b))
            }
            SmallButton("›") {
                val p = player ?: return@SmallButton
                p.seekTo(p.currentPosition + 1000)
            }
            Spacer(Modifier.weight(1f))
            SmallButton("‹") {
                val p = player ?: return@SmallButton
                p.seekTo(max(0L, p.currentPosition - 1000))
            }
            ABButton("B", b) {
                b = player?.currentPosition
                onUpdate(slot.copy(aMs = a, bMs = b))
            }
            SmallButton("›") {
                val p = player ?: return@SmallButton
                p.seekTo(p.currentPosition + 1000)
            }
            Text("→", color = Text, fontSize = 22.sp)
        }

        Row(
            Modifier.fillMaxWidth().height(66.dp).padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Text("▣", color = Text, fontSize = 22.sp)
            Text("I◀", color = Text, fontSize = 21.sp)
            Text("↶10", color = Text, fontSize = 19.sp)
            PlayButton(player)
            Text("10↷", color = Text, fontSize = 19.sp)
            Text("▶I", color = Text, fontSize = 21.sp)
            Text("⛶", color = Text, fontSize = 22.sp)
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(formatTime(position), color = Text, fontSize = 12.sp)
            Slider(
                value = if (duration > 0) position.toFloat() / duration else 0f,
                onValueChange = { f -> player?.seekTo((duration * f).toLong()) },
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)
            )
            Text(formatTime(duration), color = Text, fontSize = 12.sp)
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("♬", color = Text, fontSize = 20.sp)
            Slider(value = volume, onValueChange = {
                volume = it
                player?.volume = it
            }, modifier = Modifier.weight(1f).padding(horizontal = 7.dp),
                colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent))
            Text("${(volume * 100).toInt()}", color = Text, fontSize = 12.sp)
            Text("${speed}x", color = Text, modifier = Modifier.padding(horizontal = 12.dp)
                .clickable {
                    speed = when (speed) { 0.5f -> 1f; 1f -> 1.5f; 1.5f -> 2f; else -> 0.5f }
                    player?.setPlaybackSpeed(speed)
                })
            Text("▤", color = Text, fontSize = 20.sp, modifier = Modifier.padding(10.dp))
            Text("↻", color = if (looping) Accent else Text, fontSize = 22.sp)
            Text("⛶", color = Text, fontSize = 21.sp, modifier = Modifier.padding(10.dp))
        }
    }
}

@Composable
fun TimeBar(position: Long, duration: Long, player: ExoPlayer?) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(formatTime(position), color = Text, fontSize = 12.sp)
        Slider(
            value = if (duration > 0) position.toFloat() / duration else 0f,
            onValueChange = { f -> player?.seekTo((duration * f).toLong()) },
            modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
            colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)
        )
        Text(formatTime(duration), color = Text, fontSize = 12.sp)
    }
}

@Composable
fun ABButton(label: String, value: Long?, onClick: () -> Unit) {
    Column(
        Modifier.width(58.dp).clickable { onClick() }.background(Panel2, RoundedCornerShape(6.dp)).padding(5.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, color = Accent, fontSize = 18.sp)
        Text(formatTime(value ?: 0), color = Accent, fontSize = 11.sp)
    }
}

@Composable
fun SmallButton(text: String, onClick: () -> Unit) {
    Text(text, color = Text, fontSize = 25.sp, modifier = Modifier.clickable { onClick() }.padding(8.dp))
}

@Composable
fun PlayButton(player: ExoPlayer?) {
    var playing by remember { mutableStateOf(false) }
    Box(
        Modifier.size(58.dp).clickable {
            if (player != null) {
                if (player.isPlaying) player.pause() else player.play()
                playing = player.isPlaying
            }
        },
        contentAlignment = Alignment.Center
    ) {
        Text(if (playing) "Ⅱ" else "▶", color = Accent, fontSize = 28.sp)
    }
}

@Composable
fun BottomPager(index: Int, count: Int, onPrev: () -> Unit, onNext: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(58.dp).background(Color(0xFF0C1115)).padding(horizontal = 28.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("‹  PREV", color = Text, modifier = Modifier.clickable { onPrev() })
        Spacer(Modifier.weight(1f))
        Text("Page ${index + 1} / $count", color = Text, fontSize = 16.sp)
        Spacer(Modifier.weight(1f))
        Text("NEXT  ›", color = Text, modifier = Modifier.clickable { onNext() })
        Spacer(Modifier.width(18.dp))
        Box(
            Modifier.size(46.dp).background(Accent, RoundedCornerShape(50.dp))
                .clickable { onNext() },
            contentAlignment = Alignment.Center
        ) { Text("+", color = Color.Black, fontSize = 28.sp) }
    }
}

fun formatTime(ms: Long): String {
    val total = max(0L, ms) / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}
