# Dual Player Android App

This is a starter Android Studio project based on the requested tablet UI:
- exactly two media players side-by-side per page
- unlimited pages, each page has two independent players
- local media picker for each player
- independent play/pause, seek, volume, playback speed and repeat
- A/B repeat controls on each player
- previous/next page navigation
- dark tablet-oriented UI with green accent

## Open
Open the `DualPlayerApp` folder in Android Studio and let Gradle sync.

## Build
Use Android Studio's Run button or:
`./gradlew assembleDebug`

The app targets landscape/tablet use.
